SELECT * FROM bookings;
SELECT * FROM seat_availability WHERE status='VACANT';
